﻿using FactoryBusinesLogic.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryBusinesLogic.Services
{
    public interface IEmployeeService
    {
        List<EmployeeModel> GetEmployees();
        void AddEmployee(EmployeeModel model);
        void UpdateEmployee(EmployeeModel model);
        void DeleteEmployee(int id);
    }
}
