﻿using FactoryBusinesLogic.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PP_zavod_ch1.FactoryBusinesLogic.FactoryBusinesLogic.Services
{
    public interface IDepartmentService
    {
        List<DepartmentModel> GetDepartments();
        List<DepartmentModel> GetDepartmentsWithHierarchy();
    }
}
