﻿using FactoryBusinesLogic.Models;
using FactoryBusinesLogic.Mappers;
using FactoryDataAccess.Repository;
using System.Collections.Generic;
using System.Linq;
using FactoryDataAccess;
using PP_zavod_ch1.FactoryBusinesLogic.FactoryBusinesLogic.Services;

namespace FactoryBusinesLogic.Services
{
    public class DepartmentService : IDepartmentService
    {
        private readonly DepartmentRepository _departmentRepository;

        public DepartmentService(ApplicationContext context)
        {
            _departmentRepository = new DepartmentRepository(context);
        }

        public List<DepartmentModel> GetDepartments()
        {
            return _departmentRepository.GetAll()
                .Select(d => d.ToModel())
                .ToList();
        }

        public DepartmentModel GetDepartmentById(int id)
        {
            var entity = _departmentRepository.GetByIdAsync(id).Result;
            return entity?.ToModel();
        }

        public void AddDepartment(DepartmentModel model)
        {
            var entity = model.ToEntity();
            _departmentRepository.AddAsync(entity).Wait();
        }

        public void UpdateDepartment(DepartmentModel model)
        {
            var entity = model.ToEntity();
            _departmentRepository.UpdateAsync(entity).Wait();
        }

        public void DeleteDepartment(int id)
        {
            var entity = _departmentRepository.GetByIdAsync(id).Result;
            if (entity != null)
            {
                _departmentRepository.DeleteAsync(entity).Wait();
            }
        }

        public List<DepartmentModel> GetDepartmentsWithHierarchy()
        {
            throw new NotImplementedException();
        }
    }
}
