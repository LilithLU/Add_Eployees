﻿using FactoryBusinesLogic.Models; // Пространство имен для модели
using FactoryDataAccess.Repository;
using FactoryDataAccess.Entity;
using System;

namespace FactoryBusinesLogic.Services
{
    public class PositionService
    {
        private readonly PositionRepository _positionRepository;

        public PositionService(PositionRepository repository)
        {
            _positionRepository = repository;
        }

        // Метод для добавления должности
        public void AddPosition(PositionModel position)
        {
            // Преобразуем PositionModel в Entity Position
            var entityPosition = new Position
            {
                PositionId = position.PositionId,
                Name = position.Name,
                DepartmentId = position.DepartmentId
            };

            // Добавляем преобразованный объект в репозиторий
            _positionRepository.AddPosition(entityPosition);
        }
    }
}
