﻿using FactoryBusinesLogic.Models;
using FactoryBusinesLogic.Mappers;
using FactoryDataAccess.Repository;
using System.Collections.Generic;
using System.Linq;
using FactoryDataAccess;

namespace FactoryBusinesLogic.Services
{
    public class EmployeeService
    {
        private readonly EmployeeRepository _employeeRepository;

        public EmployeeService(string connectionString)
        {
            var context = new ApplicationContext(connectionString); // Создаем ApplicationContext
            _employeeRepository = new EmployeeRepository(context); // Передаем его в репозиторий
        }

        public List<EmployeeModel> GetEmployees()
        {
            return _employeeRepository.GetAll()
                .Select(e => e.ToModel())
                .ToList();
        }

        public void AddEmployee(EmployeeModel model)
        {
            var entity = model.ToEntity();
            _employeeRepository.AddAsync(entity).Wait();
        }

        public void UpdateEmployee(EmployeeModel model)
        {
            var entity = model.ToEntity();
            _employeeRepository.UpdateAsync(entity).Wait();
        }

        public void DeleteEmployee(int id)
        {
            var entity = _employeeRepository.GetByIdAsync(id).Result;
            if (entity != null)
            {
                _employeeRepository.DeleteAsync(entity).Wait();
            }
        }
    }
}
