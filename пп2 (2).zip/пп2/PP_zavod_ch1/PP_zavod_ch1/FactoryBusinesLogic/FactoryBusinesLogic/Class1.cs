﻿namespace FactoryBusinesLogic
{
    public class Class1
    {

    }
}
