﻿using FactoryDataAccess.Entity;
using FactoryBusinesLogic.Models;

namespace FactoryBusinesLogic.Mappers
{
    public static class ModelMapper
    {
        public static DepartmentModel ToModel(this Department entity)
        {
            return new DepartmentModel
            {
                DepartmentId = entity.DepartmentId,
                Name = entity.Name,
                ParentId = entity.ParentId,
                SubDepartments = new System.Collections.ObjectModel.ObservableCollection<DepartmentModel>(),
                Positions = new System.Collections.ObjectModel.ObservableCollection<PositionModel>(),
                Employees = new System.Collections.ObjectModel.ObservableCollection<EmployeeModel>()
            };
        }

        public static Department ToEntity(this DepartmentModel model)
        {
            return new Department
            {
                DepartmentId = model.DepartmentId,
                Name = model.Name,
                ParentId = model.ParentId
            };
        }

        public static PositionModel ToModel(this Position entity)
        {
            return new PositionModel
            {
                PositionId = entity.PositionId,
                Name = entity.Name,
                DepartmentId = entity.DepartmentId
            };
        }

        public static Position ToEntity(this PositionModel model)
        {
            return new Position
            {
                PositionId = model.PositionId,
                Name = model.Name,
                DepartmentId = model.DepartmentId
            };
        }

        public static EmployeeModel ToModel(this Employee entity)
        {
            return new EmployeeModel
            {
                EmployeeId = entity.EmployeeId,
                FirstName = entity.FirstName,
                LastName = entity.LastName,
                MiddleName = entity.MiddleName,
                HireDate = entity.HireDate,
                PositionId = entity.PositionId
            };
        }

        public static Employee ToEntity(this EmployeeModel model)
        {
            return new Employee
            {
                EmployeeId = model.EmployeeId,
                FirstName = model.FirstName,
                LastName = model.LastName,
                MiddleName = model.MiddleName,
                HireDate = model.HireDate,
                PositionId = model.PositionId
            };
        }
    }
}
