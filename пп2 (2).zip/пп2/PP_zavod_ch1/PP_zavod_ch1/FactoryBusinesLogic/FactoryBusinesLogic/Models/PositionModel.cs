﻿namespace FactoryBusinesLogic.Models
{
    public class PositionModel
    {
        public int PositionId { get; set; }
        public string Name { get; set; }
        public int? DepartmentId { get; set; }
    }
}
