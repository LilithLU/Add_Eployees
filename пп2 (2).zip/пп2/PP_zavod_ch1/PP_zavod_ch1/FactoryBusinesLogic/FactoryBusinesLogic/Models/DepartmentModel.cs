﻿using System.Collections.ObjectModel;

namespace FactoryBusinesLogic.Models
{
    public class DepartmentModel
    {
        public int DepartmentId { get; set; }
        public string Name { get; set; }
        public int? ParentId { get; set; }
        public ObservableCollection<DepartmentModel> SubDepartments { get; set; }
        public ObservableCollection<PositionModel> Positions { get; set; }
        public ObservableCollection<EmployeeModel> Employees { get; set; }
    }
}
