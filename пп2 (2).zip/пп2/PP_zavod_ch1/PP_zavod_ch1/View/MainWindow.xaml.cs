﻿using FactoryBusinesLogic.Models;
using FactoryBusinesLogic.Services;
using FactoryDataAccess.Entity;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using FactoryDataAccess.Repository; 
using PP_zavod_ch1.ViewModel;
using FactoryDataAccess;
namespace PP_zavod_ch1
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<DepartmentModel> Departments { get; set; }

        public MainWindow()
        {
            InitializeComponent();

            // Создаем один экземпляр ApplicationContext
            var context = new ApplicationContext(@"Data Source=localhost;Database=PPzavod;Integrated Security=True; TrustServerCertificate=True;");

            // Создаем зависимости с использованием общего контекста
            var departmentService = new DepartmentService(context);
            var departmentRepository = new DepartmentRepository(context);
            var positionRepository = new PositionRepository(context);
            var employeeRepository = new EmployeeRepository(context);

            // Устанавливаем DataContext
            this.DataContext = new MainWindowViewModel(
                departmentRepository,
                positionRepository,
                employeeRepository,
                departmentService);
        }



        // Обработчик для изменения выбранного элемента в TreeView
        private void OrganizationTree_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue is DepartmentModel selectedDepartment)
            {
                // Проверка, есть ли в департаменте позиция "Инженер-программист"
                var selectedPosition = selectedDepartment.Positions.FirstOrDefault(p => p.Name == "Инженер-программист");

                if (selectedPosition != null)
                {
                    // Если позиция найдена, показываем блок с информацией о сотруднике
                    EmployeeInfoGroup.Visibility = Visibility.Visible;
                }
                else
                {
                    // Если выбранный элемент не соответствует "Инженер-программист", скрываем блок
                    EmployeeInfoGroup.Visibility = Visibility.Collapsed;
                }
            }
        }


        // Обработчик для кнопки "Добавить"
        private void AddNodeImage_MouseDown(object sender, RoutedEventArgs e)
        {
            // Логика добавления нового элемента
            MessageBox.Show("Добавить новый элемент.");
        }

        // Обработчик для кнопки "Редактировать"
        private void EditNodeImage_MouseDown(object sender, RoutedEventArgs e)
        {
            // Логика редактирования выбранного элемента
            MessageBox.Show("Редактировать выбранный элемент.");
        }

        // Обработчик для кнопки "Удалить"
        private void DeleteNodeImage_MouseDown(object sender, RoutedEventArgs e)
        {
            // Логика удаления выбранного элемента
            MessageBox.Show("Удалить выбранный элемент.");
        }

        // Обработчик для кнопки "Справка"
        private void SpravkaImage_MouseDown(object sender, RoutedEventArgs e)
        {
            // Логика отображения справки
            MessageBox.Show("Показать справку.");
        }

        // Обработчик для кнопки "Выбрать сотрудника"
        private void SelectEmployeeButton_Click(object sender, RoutedEventArgs e)
        {
            // Логика выбора сотрудника
            MessageBox.Show("Выбран сотрудник.");
        }

        // Обработчик для кнопки "Очистить"
        private void ClearEmployeeInfoButton_Click(object sender, RoutedEventArgs e)
        {
            // Логика очистки информации о сотруднике
            LastNameTextBox.Clear();
            FirstNameTextBox.Clear();
            MiddleNameTextBox.Clear();
            HireDatePicker.SelectedDate = null;
            MessageBox.Show("Информация очищена.");
        }
    }
}
