using FactoryDataAccess.Repository;
using FactoryDataAccess.Entity;
using FactoryDataAccess;
using System.Collections.ObjectModel;
using System.Linq;
using Xunit;

namespace FactoryDataAccessTest
{
    public class UnitTest1
    {
        private readonly ApplicationContext _context;
        private readonly DepartmentRepository _repository;

        public UnitTest1()
        {
            _context = new ApplicationContext("Server=localhost;Database=PPzavod;Trusted_Connection=True;TrustServerCertificate=True;");
            _repository = new DepartmentRepository(_context);
        }

        [Fact]
        public void TestGetAll()
        {
            // Act
            ObservableCollection<Department> depart = new ObservableCollection<Department>(_repository.GetAll());

            // Assert
            Assert.NotNull(depart);
            Assert.True(depart.Count > 0, "The collection should not be empty.");
        }

        [Fact]
        public async Task TestAddAsync()
        {
            // Arrange
            var newDepartment = new Department
            {
                Name = "New Test Department",
                ParentId = null
            };

            // Act
            await _repository.AddAsync(newDepartment);
            var addedDepartment = await _repository.GetByIdAsync(newDepartment.DepartmentId);

            // Assert
            Assert.NotNull(addedDepartment);
            Assert.Equal("New Test Department", addedDepartment.Name);

            // Cleanup
            await _repository.DeleteAsync(newDepartment);
        }

        [Fact]
        public async Task TestGetByIdAsync()
        {
            // Arrange
            var existingDepartment = _repository.GetAll().FirstOrDefault();
            Assert.NotNull(existingDepartment);

            // Act
            var department = await _repository.GetByIdAsync(existingDepartment.DepartmentId);

            // Assert
            Assert.NotNull(department);
            Assert.Equal(existingDepartment.Name, department.Name);
        }

        [Fact]
        public async Task TestUpdateAsync()
        {
            // Arrange
            var department = _repository.GetAll().FirstOrDefault();
            Assert.NotNull(department);

            var originalName = department.Name;
            department.Name = "Updated Department Name";

            // Act
            await _repository.UpdateAsync(department);
            var updatedDepartment = await _repository.GetByIdAsync(department.DepartmentId);

            // Assert
            Assert.NotNull(updatedDepartment);
            Assert.Equal("Updated Department Name", updatedDepartment.Name);

            // Cleanup
            department.Name = originalName;
            await _repository.UpdateAsync(department);
        }

        [Fact]
        public async Task TestDeleteAsync()
        {
            // Arrange
            var departmentToDelete = new Department
            {
                Name = "Department to Delete",
                ParentId = null
            };

            await _repository.AddAsync(departmentToDelete);

            // Act
            await _repository.DeleteAsync(departmentToDelete);
            var deletedDepartment = await _repository.GetByIdAsync(departmentToDelete.DepartmentId);

            // Assert
            Assert.Null(deletedDepartment);
        }
    }
}
