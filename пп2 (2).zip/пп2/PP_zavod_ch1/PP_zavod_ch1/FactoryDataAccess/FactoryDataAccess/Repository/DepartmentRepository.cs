﻿using Microsoft.Data.SqlClient;
using System.Collections.Generic;
using FactoryDataAccess.Entity;
using FactoryDataAccess.Repository.Abstractions;

namespace FactoryDataAccess.Repository
{
    public class DepartmentRepository : IRepository<Department>
    {
        public readonly ApplicationContext _context;

        public DepartmentRepository(ApplicationContext context)
        {
            _context = context;
        }

        public async Task<Department> GetByIdAsync(int id)
        {
            return await _context.departmens.FindAsync(id);
        }

        public IEnumerable<Department> GetAll() 
        {
            return _context.departmens.AsEnumerable();
        }

        public async Task AddAsync(Department entity)
        {
            await _context.departmens.AddAsync(entity);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Department entity)
        {
            _context.Update(entity);
            await _context.SaveChangesAsync();
        }
        public async Task DeleteAsync(Department entity)
        {
            _context.departmens.Remove(entity);
            await _context.SaveChangesAsync();
        }       
    }
}