﻿using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using FactoryDataAccess.Entity;

namespace FactoryDataAccess.Repository
{
    public class PositionRepository 
    {
        private readonly ApplicationContext _context;

        public PositionRepository(ApplicationContext context)
        {
            _context = context;
        }
        public void AddPosition(Position position)
        {
            using (var connection = new SqlConnection(_context))
            {
                connection.Open();
                var command = new SqlCommand("INSERT INTO Positions (Name, DepartmentId) VALUES (@Name, @DepartmentId)", connection);
                command.Parameters.AddWithValue("@Name", position.Name);
                command.Parameters.AddWithValue("@DepartmentId", position.DepartmentId);

                command.ExecuteNonQuery();
            }
        }

        public List<Position> GetPositions()
        {
            var positions = new List<Position>();
            using (var connection = new SqlConnection(_context))
            {
                connection.Open();
                var command = new SqlCommand("SELECT PositionId, Name, DepartmentId FROM Positions", connection);
                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    positions.Add(new Position
                    {
                        PositionId = reader.GetInt32(0),
                        Name = reader.GetString(1),
                        DepartmentId = reader.IsDBNull(2) ? (int?)null : reader.GetInt32(2)
                    });
                }
            }
            return positions;
        }
    }
}
