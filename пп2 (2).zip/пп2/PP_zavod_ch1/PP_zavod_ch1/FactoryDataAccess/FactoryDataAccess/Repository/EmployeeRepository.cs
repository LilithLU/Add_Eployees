﻿using Microsoft.Data.SqlClient;
using FactoryDataAccess.Entity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace FactoryDataAccess.Repository
{
    public class EmployeeRepository
    {
        private readonly string _connectionString;

        public EmployeeRepository(ApplicationContext context)
        {
            // Извлекаем строку подключения из ApplicationContext
            _connectionString = context.Database.GetDbConnection().ConnectionString;
        }

        // Метод для получения всех сотрудников
        public List<Employee> GetAll()
        {
            var employees = new List<Employee>();
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT EmployeeId, LastName, FirstName, MiddleName, HireDate, PositionId FROM Employees", connection);
                using var reader = command.ExecuteReader();
                while (reader.Read())
                {
                    employees.Add(new Employee
                    {
                        EmployeeId = reader.GetInt32(0),
                        LastName = reader.GetString(1),
                        FirstName = reader.GetString(2),
                        MiddleName = reader.GetString(3),
                        HireDate = reader.GetDateTime(4),
                        PositionId = reader.GetInt32(5)
                    });
                }
            }
            return employees;
        }

        // Асинхронный метод для добавления сотрудника
        public async Task AddAsync(Employee employee)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("INSERT INTO Employees (LastName, FirstName, MiddleName, HireDate, PositionId) VALUES (@LastName, @FirstName, @MiddleName, @HireDate, @PositionId)", connection);
                command.Parameters.AddWithValue("@LastName", employee.LastName);
                command.Parameters.AddWithValue("@FirstName", employee.FirstName);
                command.Parameters.AddWithValue("@MiddleName", employee.MiddleName);
                command.Parameters.AddWithValue("@HireDate", employee.HireDate);
                command.Parameters.AddWithValue("@PositionId", employee.PositionId);
                await command.ExecuteNonQueryAsync();
            }
        }

        // Асинхронный метод для обновления данных сотрудника
        public async Task UpdateAsync(Employee employee)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("UPDATE Employees SET LastName = @LastName, FirstName = @FirstName, MiddleName = @MiddleName, HireDate = @HireDate, PositionId = @PositionId WHERE EmployeeId = @EmployeeId", connection);
                command.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
                command.Parameters.AddWithValue("@LastName", employee.LastName);
                command.Parameters.AddWithValue("@FirstName", employee.FirstName);
                command.Parameters.AddWithValue("@MiddleName", employee.MiddleName);
                command.Parameters.AddWithValue("@HireDate", employee.HireDate);
                command.Parameters.AddWithValue("@PositionId", employee.PositionId);
                await command.ExecuteNonQueryAsync();
            }
        }

        // Метод для получения сотрудника по ID
        public async Task<Employee> GetByIdAsync(int id)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("SELECT EmployeeId, LastName, FirstName, MiddleName, HireDate, PositionId FROM Employees WHERE EmployeeId = @EmployeeId", connection);
                command.Parameters.AddWithValue("@EmployeeId", id);
                using var reader = await command.ExecuteReaderAsync();
                if (reader.Read())
                {
                    return new Employee
                    {
                        EmployeeId = reader.GetInt32(0),
                        LastName = reader.GetString(1),
                        FirstName = reader.GetString(2),
                        MiddleName = reader.GetString(3),
                        HireDate = reader.GetDateTime(4),
                        PositionId = reader.GetInt32(5)
                    };
                }
            }
            return null;
        }

        // Асинхронный метод для удаления сотрудника
        public async Task DeleteAsync(Employee employee)
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var command = new SqlCommand("DELETE FROM Employees WHERE EmployeeId = @EmployeeId", connection);
                command.Parameters.AddWithValue("@EmployeeId", employee.EmployeeId);
                await command.ExecuteNonQueryAsync();
            }
        }
    }
}
