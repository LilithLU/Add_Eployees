﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using FactoryDataAccess.Entity;
using System.Collections.Generic;

namespace FactoryDataAccess
{
    public class ApplicationContext:DbContext
    {
        public ApplicationContext(string connectionString):base(GetOptions(connectionString))
        { 

        }
        public DbSet<Department> departmens { get; set; }
        public DbSet<Employee> employees { get; set; }
        public DbSet<Position> positions { get; set; }

        private static DbContextOptions GetOptions(string connectionString)
        {
            var optionsBuilder = new DbContextOptionsBuilder();
            var connectionStringBuilder = new SqlConnectionStringBuilder(connectionString);
            optionsBuilder.UseSqlServer(connectionStringBuilder.ConnectionString);
            return optionsBuilder.Options;  
        }

    }
}
