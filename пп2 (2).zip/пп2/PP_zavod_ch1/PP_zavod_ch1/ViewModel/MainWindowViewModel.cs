﻿using FactoryBusinesLogic.Models;
using FactoryDataAccess.Repository;
using FactoryBusinesLogic.Services;
using System.Collections.ObjectModel;
using PP_zavod_ch1.FactoryBusinesLogic.FactoryBusinesLogic.Services;

namespace PP_zavod_ch1.ViewModel
{
    public class MainWindowViewModel : ViewModelBase
    {
        private readonly IDepartmentService _departmentService;

        public ObservableCollection<DepartmentModel> Departments { get; set; }

        // Конструктор, который принимает все необходимые зависимости
        public MainWindowViewModel(
            DepartmentRepository departmentRepository,
            PositionRepository positionRepository,
            EmployeeRepository employeeRepository,
            IDepartmentService departmentService)
        {
            _departmentService = departmentService;

            LoadDepartments();
        }

        private void LoadDepartments()
        {
            var departments = _departmentService.GetDepartmentsWithHierarchy();
            Departments = new ObservableCollection<DepartmentModel>(departments);
        }
    }
}
